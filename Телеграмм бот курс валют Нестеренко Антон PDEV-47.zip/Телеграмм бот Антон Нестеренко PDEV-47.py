import telebot
import config
from extensions import APIException, Converter

bot = telebot.TeleBot(config.TOKEN)


@bot.message_handler(commands=['start'])
def start_message(message: telebot.types.Message):
    text = config.text_start
    bot.reply_to(message, text)


@bot.message_handler(commands=['help'])
def help_message(message: telebot.types.Message):
    text = config.text_help
    bot.reply_to(message, text)


@bot.message_handler(commands=['values'])
def values(message: telebot.types.Message):
    text = config.text_values
    bot.reply_to(message, text)


@bot.message_handler(content_types=['text', ])
def convert(message: telebot.types.Message):
    try:
        value = message.text.split(' ')

        if len(value) != 3:
            raise APIException('Запрос введен в неверном формате! \nЧтобы уточнить формат запроса \
воспользуйся командой /help')

        quote, base, amount = value
        total_base = Converter.get_price(quote, base, amount)

    except APIException as e:
        bot.reply_to(message, f'Ошибка пользователя\n {e}')
    except Exception as e:
        bot.reply_to(message, f'Не удалось обработать команду\n {e}')
    else:
        text = f'Цена {amount} {quote} в {base} = {total_base} {base}'
        bot.send_message(message.chat.id, text)


bot.polling()
