import requests
import json
from config import keys


class APIException(Exception):
    pass


class Converter:
    @staticmethod
    def get_price(quote: str, base: str, amount: str):
        try:
            quote_ticker = keys[quote]
        except KeyError:
            raise APIException(f'Не работаю с валютой {quote}!')

        try:
            base_ticker = keys[base]
        except KeyError:
            raise APIException(f'Не работаю с валютой {base}!')

        if quote == base:
            raise APIException('Для конвертации валюты должны различаться!')

        try:
            amount = float(amount)
        except ValueError:
            raise APIException(f'Не удалось обработать количество {amount}!')

        r = requests.get(f'https://min-api.cryptocompare.com/data/price?fsym={quote_ticker}&tsyms={base_ticker}')
        total_base = (json.loads(r.content)[keys[base]]) * amount

        return total_base
